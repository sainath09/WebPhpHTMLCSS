<?php
 header("location:../");
?>