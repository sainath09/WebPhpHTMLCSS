<!DOCTYPE html>
<html>
    <head>
        <title>Free hosting, web host free, free websites hosting, freewebsite</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="content-language" content="en">
        <meta name="keywords" content="Free hosting, site pubisher, website builder, hosting, web, web host, free web hosting, freehosting, hosting for free, web host free, free websites hosting, freewebsite, PHP, MySQL, No Ads, cPanel, site builder, unlimited, 1freehosting" >
        <meta name="description" content="Free hosting site was ready. 1FreeHosting.com - free and mostly unlimited web hosting with PHP, MySQL, No Ads, Site builder, cPanel." >
        <style type="text/css">
            html, body							{ height:100% !important; min-height:100%; }
            body, form							{ padding:0; margin:0; }
            body								{ background-color: #890000; color: #FFFFFF;   font-family: Arial,georgia;    font-size: 13px;}
            div, input, textarea, select		{ position:relative; }

            a									{ color:#FF9933; outline:none; text-decoration:none; }
            a:hover								{ text-decoration:underline; }

            #start					{ width:100%; min-width:1003px; min-height:600px; height:100%; }
            #bef-main				{ width:100%; min-height:100%; overflow:hidden; }
            #main					{ width:100%; height:509px; position:absolute; margin:0 auto; top:50%; }
            .borders				{ padding:10px; background: url(http://cpanel.1freehosting.com/themes/login/images/borders.png) no-repeat; width:955px; height:509px; top:-50%; margin:0 auto; }
            .picture				{ width:955px; height:509px; overflow:auto; background:#5f0200 url("http://www.1freehosting.com/public/themes/1fh/images/logo-inner-top.png") no-repeat scroll 70px 0;}

            #free-hosting			{ margin: 200px 0 0 0; }
            #free-hosting h1, #free-hosting h2 			{ text-align: center;}
            #free-hosting h1 span.ok{ color: #FF9933; }
            #free-hosting ul        { margin: 30px 0 0 50px; }
            #foot					{ width:955px; text-align:right; margin:0 auto; padding-top:13px; }
            #foot a					{ color:#fff; }

        </style>
    </head>

    <body>
        <div id="start">
            <div id="bef-main">
                <div id="main">
                    <div class="borders">
                        <div class="picture" title="1FreeHosting.com">
                            <div id="free-hosting">
                                <h1><span class="ok">Congratulations!</span> Your website is up and running!</h1>
                                <h2>Here are some tips to get started with your new account</h2>
                                <ul>
                                    <li>Use <a href="http://cpanel.1freehosting.com/website/auto-installer">"Autoinstaller"</a> to install most popular software such as Wordpress, Drupal, Joomla, phpBB or osCommerce</li>
                                    <li>Use <a href="http://cpanel.1freehosting.com/website/builder">"Website Builder"</a> to build your website without any HTML knowledge</li>
                                    <li>Upload your site by using FTP or web based File Manager.</li>
                                    <li>Already have an existing site? Create "zip" file and <a href="http://cpanel.1freehosting.com/website/import">import it</a>.</li>
                                    <li>If you have any questions please <a href="http://cpanel.1freehosting.com/helpdesk">contact us</a>.</li>
<li>Please delete the file "default.php" from the public_html folder
before installing your new website.</li>
</li>
<li>Follow us on <a href="https://facebook.com/1freehosting">Facebook</a>.</li>
<li>Grab your reward at <a href="http://www.1freehosting.com/fan-zone">Fan Zone</a>.</li>
<li>Make <a href="http://www.1pagerank.com/?utm_source=welcome-page&utm_medium=click&utm_campaign=Welcome+Page">SEO analysis</a> for your website.</li>
                                </ul>
                            </div>
                        </div>
                        <div id="foot"><a href="http://www.1freehosting.com/">&copy; 2013 All rights reserved 1FreeHosting.com</a></div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<!--DEFAULT_WELCOME_PAGE-->
