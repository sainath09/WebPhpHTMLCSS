<?php
include('common.php');

error_reporting(0);
class User
{
	public function safe($string)
	{
		$string = stripslashes($string);
		$string = mysql_real_escape_string($string);
		$string = strip_tags($string);
		//$string = htmlspecialchars($string);
		$string = htmlentities($string, ENT_QUOTES | ENT_IGNORE, "UTF-8");
		return $string;
	}

}

$user = new User();
if ($_SERVER["REQUEST_METHOD"] == "POST") 
  {
		$name = $_POST['name'];
		
		$email = $_POST['email'];
		$sub = $_POST['sub'];
		
		$msg= $_POST['msg'];
		
		
		
		
		$name = $user->safe($name);
		
		
		
		
		$sql=mysql_query("INSERT into quiery(name,email,sub,msg) VALUES ('$name','$email','$sub','$msg')") or die(mysql_error());

	
  }
?>

<html>
<body>
<h1>Have a cup of coffee. We will get back to you soon.
<h1></h1>
</body>
</html>